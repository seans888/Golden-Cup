<footer>
	<div class ="col-md-6">
	
	</div>
	<div class ="col-md-2">
		<p class ="text-center"><a href="/">Home</a></p>
		<p class ="text-center"><a href="/parts">Parts</a></p>
		<p class ="text-center"><a href="/payment_methods">Payment Methods</a></p>
	</div>
	<div class ="col-md-2">
		<p class ="text-center"><a href="/">About Us</a></p>
		<p class ="text-center"><a href="/kyocera">Kyocera</a></p>
		<p class ="text-center"><a href="/register">Register</a></p>
	</div>
	<div class ="col-md-2 text-right">
		<p class ="text-center"><a href="/about">Copiers</a></p>
		<p class ="text-center"><a href="/copiers">Ricoh</a></p>
		<p class ="text-center"><a href="/login">Member Login</a></p>
	</div>
        <div class="col-lg-12">
            <p class="text-right"><strong>Copyright &copy; Golden Cup 2017<strong></p>
        </div>
</footer>