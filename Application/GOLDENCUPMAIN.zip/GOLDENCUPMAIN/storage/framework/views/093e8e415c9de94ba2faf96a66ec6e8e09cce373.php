<?php $__env->startSection('title', '| Login'); ?>

<?php $__env->startSection('content'); ?>



    <div class="row">
        <div class="col-md-6 col-md-offset-3">


            <br>
            <h1 class="text-center"> Sign In </h1>
            <br>
            <hr>
            <?php echo e(Form::open()); ?>

            <?php echo e(Form::label('email','E-mail:')); ?>

            <?php echo e(Form::email('email', null, array('class'=> 'form-control'))); ?>



            <?php echo e(Form::label('password', 'Password: ')); ?>

            <?php echo e(Form::password('password', array('class' => 'form-control'))); ?>


            <br>
            <?php echo e(Form::label('remember', 'Remember Me')); ?>

            <?php echo e(Form::checkbox('remember')); ?>


            <br>
            <?php echo e(Form::submit('Login', array('class' => 'btn btn-primary btn-block'))); ?>

            <a class="btn btn-success btn-block" href="/register"> Create an account</a>

            <?php echo e(Form::close()); ?>



            <?php if(count($errors) > 0): ?>
                <br>

                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <hr>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>