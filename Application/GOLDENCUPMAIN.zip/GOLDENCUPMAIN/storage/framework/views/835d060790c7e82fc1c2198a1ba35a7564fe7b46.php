<footer>
    <div class="row">
        <div class="col-lg-12">
            <p class="text-center">Copyright &copy; Golden Cup 2017</p>
        </div>
    </div>
</footer>