
Clone repo

 		git clone https://github.com/webdevmatics/ecom.git
        
Install the composer dependencies

		composer install
Set application key

		php artisan key:generate        

Configure .env and migrate 
