<?php $__env->startSection('title', ' | Home'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Jumbotron Header -->
    <div class="row">
        <div class="col-md-1 col-sm-1">
        </div>
        <div id="myCarousel" class="col-md-10 col-sm-10 carousel" data-ride="carousel">
            <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox">
                <div class="item active">
                    <img src="/images/slider-1.jpg" align="middle" width="100%" alt="Slide1">
                </div>

                <div class="item">
                    <img src="/images/slider-3.jpg" align="middle" width="100%" alt="Slide2">
                </div>

                <div class="item">
                    <img src="/images/slider-4.jpg" align="middle" width="100%" alt="Slide3">
                </div>
            </div>
        </div>
        <div class="col-md-1 col-sm-1">
        </div>
    </div>

    <hr style = "visibility: hidden;">

    <!-- Title -->
    <div class="row" style="display: inline;">
        <?php $__empty_1 = true; $__currentLoopData = $copiers->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $copier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-3 col-md-3 col-lg-3 columns">
                    <div class="item-wrapper">
                        <a href="#">
                            <img src="<?php echo e(url('images',$copier->image)); ?>"/>
                        </a>
                        <a href="<?php echo e(route('copiers')); ?>">
                            <h3>
                                <?php echo e($copier->name); ?>

                            </h3>
                        </a>
                        <h5>
                            &#8369;<?php echo e($copier->price); ?>


                        </h5>
                        <p>
                            <?php echo e($copier->description); ?>

                        </p>

                        <div class="img-wrapper">
                            <?php if(Auth::check()): ?>
                                <a href="<?php echo e(route('cart.addItem',$copier->id)); ?>" class="btn btn-primary">
                                    Add to Cart
                                </a>
                            <?php else: ?>
                                <a href="<?php echo e(url('login')); ?>" class="btn btn-primary" > Add to Cart</a>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h3>No Copier</h3>
        <?php endif; ?>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>