<?php $__env->startSection('title','| Copier Machines'); ?>
<?php $__env->startSection('content'); ?>
    <!-- products listing -->
    <!-- Latest SHirts -->
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $copiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $copier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-sm-3 col-md-3 col-lg-3 columns">
                <div class="item-wrapper">
                    <div class="img-wrapper">
                        <a href="<?php echo e(route('cart.addItem',$copier->id)); ?>" class="button expanded add-to-cart">
                            Add to Cart
                        </a>
                        <a href="#">
                            <img src="<?php echo e(url('images',$copier->image)); ?>"/>
                        </a>
                    </div>
                    <a href="<?php echo e(route('home')); ?>">
                        <h3>
                            <?php echo e($copier->name); ?>

                        </h3>
                    </a>
                    <h5>
                        $<?php echo e($copier->price); ?>


                    </h5>
                    <p>
                        <?php echo e($copier->description); ?>

                    </p>
                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h3>No Copiers</h3>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>